for _, source in ipairs {
  "astronvim.bootstrap",
  "astronvim.mapping-document",
  "astronvim.options",
  "astronvim.lazy",
  "astronvim.autocmds",
  "astronvim.mappings",
  "astronvim.prettier",
  -- "astronvim.tabnine",
  "astronvim.utils.status",
  "astronvim.lsp",
  "astronvim.vim",
  "astronvim.rest",
} do
  local status_ok, fault = pcall(require, source)
  if not status_ok then vim.api.nvim_err_writeln("Failed to load " .. source .. "\n\n" .. fault) end
end

if astronvim.default_colorscheme then
  if not pcall(vim.cmd.colorscheme, astronvim.default_colorscheme) then
    require("astronvim.utils").notify(
      "Error setting up colorscheme: " .. astronvim.default_colorscheme,
      vim.log.levels.ERROR
    )
  end
end

require("astronvim.utils").conditional_func(astronvim.user_opts("polish", nil, false), true)
require("colorizer").setup {
  filetypes = {
    "*",                      -- Highlight all files, but customize some others.
    css = { rgb_fn = true },  -- Enable parsing rgb(...) functions in css.
    html = { names = false }, -- Disable parsing "names" like Blue or Gray
    conf = { rgb_fn = true },
  },
}

vim.cmd [[
augroup ClearYankRegister
  autocmd!
  autocmd InsertLeave * :let @0=''
augroup END
]]
