local opts = { noremap = true, silent = true }
local on = 0

vim.keymap.set("n", "<F12>", function()
  if vim.o.conceallevel > 0 then
    vim.o.conceallevel = 0
  else
    vim.o.conceallevel = 2
  end
end, opts)

vim.keymap.set("n", "<leader>msn", function()
  if vim.o.concealcursor == "n" then
    vim.o.concealcursor = ""
  else
    vim.o.concealcursor = "n"
  end
end, opts)

vim.keymap.set("n", "<leader>a", function()
  if on == 0 then
    vim.api.nvim_exec [[
        au BufEnter,BufNewFile *.js,*.jsx set filetype=javascript.html
        au BufEnter,BufNewFile *.php set filetype=php.html
      ]]
    on = 1
  else
    vim.api.nvim_exec [[
        au BufEnter,BufNewFile *.js set filetype=javascript.js
        au BufEnter,BufNewFile *.jsx set filetype=javascript.jsx
        au BufEnter,BufNewFile *.php set filetype=php.php
      ]]
    on = 0
  end
end, opts)

-- vim.api.nvim_exec(
--   [[
--     au BufEnter,BufNewFile *.js,*.jsx set filetype=javascript.html
--     au BufEnter,BufNewFile *.php set filetype=php.html
--   ]],
--   false
-- )
