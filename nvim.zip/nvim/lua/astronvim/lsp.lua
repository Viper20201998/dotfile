local ok, lspconfig = pcall(require, "lspconfig")

if not ok then return end

lspconfig.html.setup {
  cmd = { "node", "/usr/lib/node_modules/vscode-html-languageserver-bin/htmlServerMain.js", "--stdio" },
  filetypes = { "php", "blade", "html", "javascriptreact" },
  root_dir = lspconfig.util.root_pattern(".git", vim.fn.getcwd()),
}

lspconfig.html.setup {
  cmd = { "emmet-ls", "--stdio" },
  filetypes = { "php" },
  root_dir = lspconfig.util.root_pattern(".git", vim.fn.getcwd()),
}

lspconfig.intelephense.setup {
  cmd = { "/home/viper/.local/share/nvim/mason/bin/intelephense", "--stdio" },
  filetypes = { "blade", "php" },
  root_dir = lspconfig.util.root_pattern(".git", vim.fn.getcwd()),
}

lspconfig.phpactor.setup {
  cmd = { "/home/viper/.local/share/nvim/mason/bin/phpactor", "language-server" },
  filetypes = { "blade", "php" },
  root_dir = lspconfig.util.root_pattern(".git", vim.fn.getcwd()),
}
